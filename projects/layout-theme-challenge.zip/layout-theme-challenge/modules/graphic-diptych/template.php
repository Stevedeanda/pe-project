
<graphic-diptych>

	<picture>
		<img src='https://peprojects.dev/images/landscape.jpg' alt='$todo'>
	</picture>
	
	<text-content>
		<h1 class='loud-voice'>This is a graphic diptych</h1>

		<p>What a fun thing that we have here</p>
	</text-content>

</graphic-diptych>
