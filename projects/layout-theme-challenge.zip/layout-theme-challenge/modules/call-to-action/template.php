
<call-to-action>
	<h2 class='heading attention-voice'>Hello! This area is to give people a moment to decide...</h2>

	<p class='story'>If they want to take some type of action. Maybe it's to tell them about something they can do.</p>

	<a class='button' href='#'>Call to Action</a>
</call-to-action>
