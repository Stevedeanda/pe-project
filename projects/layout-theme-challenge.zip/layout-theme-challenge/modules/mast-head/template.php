
<mast-head>

	<nav class='site-menu'>
		<ul>
			<li>
				<a class='home' href='#'>
					<?php include('modules/logo.php'); ?>
				</a>
			</li>

			<li>
				<a href='#'>Some page</a>
			</li>

			<li>
				<a href='#'>Some other page</a>
			</li>
		</ul>
	</nav>

	<nav class='user-menu'>
		<ul>
			<li>
				<a class='button' href='#'>Sign in</a>
			</li>
		</ul>
	</nav>

</mast-head>
