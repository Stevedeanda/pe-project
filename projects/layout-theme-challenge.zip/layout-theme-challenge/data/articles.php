<?php

$articles = [
	[
		"heading" => "Article or product",
		"description" => "Here's a little info to help you understand if this is a thing you want to know about.",
		"thumbnail" => "landscape.jpg",
	],
	[
		"heading" => "Destination or option",
		"description" => "Here's a little info to help you understand if this is a thing you want to know about.",
		"thumbnail" => "landscape.jpg",
	],
	[
		"heading" => "Story or something",
		"description" => "Here's a little info to help you understand if this is a thing you want to know about.",
		"thumbnail" => "landscape.jpg",
	],
	[
		"heading" => "Banana tandori",
		"description" => "Here's a little info to help you understand if this is a thing you want to know about.",
		"thumbnail" => "landscape.jpg",
	],
	[
		"heading" => "Bar B Q",
		"description" => "Here's a little info to help you understand if this is a thing you want to know about.",
		"thumbnail" => "landscape.jpg",
	],
	[
		"heading" => "Marsala",
		"description" => "Here's a little info to help you understand if this is a thing you want to know about.",
		"thumbnail" => "landscape.jpg",
	],
];
